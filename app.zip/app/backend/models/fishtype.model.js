// require mongoose
// const mongoose = require('mongoose');

// // mongoose schema class
// const Schema = mongoose.Schema;

// // Fish Type schema
// const fishTypeSchema = new Schema({
//     FishType: { type: String, required: true, trim: true }
// });

// // create FishType model
// const Fish = mongoose.model('FishType', fishTypeSchema);

// // export fish type
// module.exports = Fish;